from django.urls import path               # path() une una dirección con una vista
from . import views                        # Las vistas de ESTA app (facturacion/views.py)

app_name = "facturacion"                   # "Apellido" de las URLs de esta app. En templates: 'facturacion:marca_lista'

urlpatterns = [
        # ---------- MARCAS (Unidad 2) ----------
    path("marcas/", views.marca_lista, name="marca_lista"),   # /facturacion/marcas/ → vista marca_lista
    # En los pasos siguientes agregarás aquí crear, editar y eliminar
    path("marcas/crear/", views.marca_crear, name="marca_crear"),   # /facturacion/marcas/crear/
       # <int:pk> captura el número de la URL y se lo pasa a la vista como parámetro pk
    path("marcas/editar/<int:pk>/", views.marca_editar, name="marca_editar"),
    path("marcas/eliminar/<int:pk>/", views.marca_eliminar, name="marca_eliminar"),
    
        # ---------- PRODUCTOS (Unidad 3) · mismas reglas: views.funcion, sin paréntesis----------
    path("productos/", views.producto_lista, name="producto_lista"),   # /facturacion/productos/
    path("productos/crear/", views.producto_crear, name="producto_crear"),   # /facturacion/productos/crear/
        # <int:pk> captura el número de la URL y se lo pasa a la función como parámetro pk
    path("productos/editar/<int:pk>/", views.producto_editar, name="producto_editar"),
    path("productos/<int:pk>/", views.producto_detalle, name="producto_detalle"),   # /facturacion/productos/7/
    path("productos/eliminar/<int:pk>/", views.producto_eliminar, name="producto_eliminar"),
    
        # ---------- CATEGORÍAS (Tarea 1) ----------
    path("categorias/", views.categoria_lista, name="categoria_lista"),                          # Listar
    path("categorias/crear/", views.categoria_crear, name="categoria_crear"),                    # Crear
    path("categorias/editar/<int:pk>/", views.categoria_editar, name="categoria_editar"),        # Editar
    path("categorias/eliminar/<int:pk>/", views.categoria_eliminar, name="categoria_eliminar"),  # Eliminar
    
        # ---------- CLIENTES (Tarea 2) ----------
    path("clientes/", views.cliente_lista, name="cliente_lista"),                          # Listar
    path("clientes/crear/", views.cliente_crear, name="cliente_crear"),                    # Crear
    path("clientes/<int:pk>/", views.cliente_detalle, name="cliente_detalle"),             # Ver uno
    path("clientes/editar/<int:pk>/", views.cliente_editar, name="cliente_editar"),        # Editar
    path("clientes/eliminar/<int:pk>/", views.cliente_eliminar, name="cliente_eliminar"),  # Eliminar
    
    # ---------- PERFIL DEL USUARIO ----------
    path("mi-perfil/", views.mi_perfil, name="mi_perfil"),   # /facturacion/mi-perfil/
]