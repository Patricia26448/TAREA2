"""
URL configuration for mi_tienda project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/6.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from . import views                                    # Nuestras vistas (también ingresar y salir)

urlpatterns = [
    path("admin/", admin.site.urls),
    path("", views.home, name="home"),
    path("saludo/", views.saludo, name="saludo"),
    path("info/", views.info_peticion, name="info"),

    # ---------- AUTENTICACIÓN (funciones) ----------
    # name="login" es importante: LOGIN_URL de settings.py lo usa para saber a dónde enviar
    path("login/", views.ingresar, name="login"),      # GET: formulario · POST: revisa y abre la sesión
    path("logout/", views.salir, name="logout"),       # Solo POST: cierra la sesión
    path("registro/", views.registro, name="registro"),   # GET: formulario · POST: crea el usuario
    path("facturacion/", include("facturacion.urls")),
]
